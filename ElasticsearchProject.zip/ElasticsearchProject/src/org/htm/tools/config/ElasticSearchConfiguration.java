package org.htm.tools.config;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.elasticsearch.action.admin.indices.settings.put.UpdateSettingsRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.settings.Settings;
import org.htm.tools.util.Utils;

public class ElasticSearchConfiguration {
	
	private Utils utils;
	private static final String MAX_RESULT_WINDOW_SETTING = "max_result_window";
	
	public RestHighLevelClient connectElasticSearch() throws IOException {
		String host = utils.getProperty("elasticsearch.host");
		int port1 = Integer.parseInt(utils.getProperty("elasticsearch.port1"));
		int port2 = Integer.parseInt(utils.getProperty("elasticsearch.port2"));
		String protocol = utils.getProperty("elasticsearch.protocol");
		
		RestHighLevelClient client = new RestHighLevelClient(
				RestClient.builder(new HttpHost(host, port1, protocol), 
						           new HttpHost(host, port2, protocol)));
		if (client != null) {
			settingIndexOf(client);
		}
		return client;
	}

	public void close(RestHighLevelClient client) throws IOException {
		client.close();
	}
	
	public void settingIndexOf(RestHighLevelClient client) throws IOException {
		UpdateSettingsRequest request = new UpdateSettingsRequest(utils.getProperty("elasticsearch.indexname"));
		int settingValue = Integer.parseInt(utils.getProperty("elasticsearch.max_result_window"));
		Settings.Builder settingsBuilder =
		        Settings.builder()
		        .put(MAX_RESULT_WINDOW_SETTING, settingValue);
		request.settings(settingsBuilder);
		client.indices().putSettings(request, RequestOptions.DEFAULT);
	}
}
