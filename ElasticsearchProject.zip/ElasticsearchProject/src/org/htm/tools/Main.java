package org.htm.tools;

import org.htm.tools.util.Utils;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Utils utils = new Utils();
		System.out.println(utils.getProperty("elasticsearch.host"));
	}

}
